# Custom Theme Theme

The **Custom Theme** Theme is for [Grav CMS](http://github.com/getgrav/grav).  This README.md file should be modified to describe the features, installation, configuration, and general usage of this theme.

## Description

Custom Theme

# Instructions

Run

`npm install` to setup tailwind and required plugins

How to build tailwind:

Development:

`npm run build` for single time compiling

`npm run watch` for constant development

Production:

`npm run prod` for production compiling. **Don't forget to turn on production mode in the theme config**# Instructions

Run

`npm install` to setup tailwind and required plugins

How to build tailwind:

Development:

`npm run build` for single time compiling

`npm run watch` for constant development

Production:

`npm run prod` for production compiling. **Don't forget to turn on production mode in the theme config**
