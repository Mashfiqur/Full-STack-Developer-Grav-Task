const toggleSidebar = () => {
    document.getElementById('sidebar').classList.toggle("-translate-x-full");
}